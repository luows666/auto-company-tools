# 个人预算管家 - Chrome 扩展程序

一个简单易用的个人记账 Chrome 扩展程序。

## 功能

- 记收入、记支出
- 本地存储数据
- 显示余额统计
- 删除记录
- 暗黑模式支持
- 专业版升级入口

## 安装方法

### 方法 1：开发者模式安装（测试用）

1. 打开 Chrome 浏览器
2. 访问 `chrome://extensions/`
3. 开启右上角的「开发者模式」
4. 点击「加载已解压的扩展程序」
5. 选择本文件夹

### 方法 2：发布到 Chrome Web Store（正式发布）

**准备事项：**
- Chrome 开发者账号（$5 一次性）
- 1280x800 截图 PNG（可选，用于商店展示）

**发布步骤：**
1. 访问 [Chrome 开发者控制台](https://chrome.google.com/webstore/devconsole)
2. 登录并支付 $5 注册开发者账号
3. 点击「新建项目」
4. 上传扩展程序 ZIP 包（包含 manifest.json、popup.html、icon*.png）
5. 填写商店信息：
   - 名称：个人预算管家
   - 描述：简单的个人记账工具
   - 类别：工具
6. 上传截图（可选）
7. 提交审核（通常 1-3 天）

### 方法 3：GitHub Release（免费发布）

1. 在 GitHub 创建新仓库 `budget-extension`
2. 推送本文件夹内容：
   ```bash
   git init
   git add -A
   git commit -m "v1.0.0 - 个人预算"
管家 Chrome 扩展   git remote add origin https://github.com/你的用户名/budget-extension.git
   git push -u origin master
   ```
3. 进入仓库 Release 页面，点击 "Draft a new release"
4. 填写版本号 v1.0.0，发布说明
5. 勾选 "pre-release"（测试版）
6. 点击 "Publish release"
7. 用户可通过 GitHub 直接下载安装

### 方法 4：直接加载（开发测试）

1. 访问 `chrome://extensions/`
2. 开启「开发者模式」
3. 点击「加载已解压的扩展程序」
4. 选择包含 manifest.json 的文件夹

## 文件结构

```
budget-extension/
├── manifest.json    # 扩展程序配置
├── popup.html       # 弹窗界面
├── icon16.png       # 16x16 图标
├── icon48.png       # 48x48 图标
├── icon128.png      # 128x128 图标
└── README.md        # 说明文档
```

## 技术说明

- 使用 Chrome Extension Manifest V3
- 数据存储使用 localStorage
- 无需服务器，完全离线可用

## 反馈

邮箱：careservice2026@163.com
